/**
 */
package atividade;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Function</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link atividade.Function#getFunctionStatement <em>Function Statement</em>}</li>
 *   <li>{@link atividade.Function#getIsLeaf <em>Is Leaf</em>}</li>
 *   <li>{@link atividade.Function#isIsAbstract <em>Is Abstract</em>}</li>
 *   <li>{@link atividade.Function#getParameter <em>Parameter</em>}</li>
 *   <li>{@link atividade.Function#getGroup <em>Group</em>}</li>
 * </ul>
 *
 * @see atividade.AtividadePackage#getFunction()
 * @model
 * @generated
 */
public interface Function extends ELement {
	/**
	 * Returns the value of the '<em><b>Function Statement</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function Statement</em>' attribute.
	 * @see #setFunctionStatement(String)
	 * @see atividade.AtividadePackage#getFunction_FunctionStatement()
	 * @model
	 * @generated
	 */
	String getFunctionStatement();

	/**
	 * Sets the value of the '{@link atividade.Function#getFunctionStatement <em>Function Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Function Statement</em>' attribute.
	 * @see #getFunctionStatement()
	 * @generated
	 */
	void setFunctionStatement(String value);

	/**
	 * Returns the value of the '<em><b>Is Leaf</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Leaf</em>' attribute.
	 * @see #setIsLeaf(String)
	 * @see atividade.AtividadePackage#getFunction_IsLeaf()
	 * @model
	 * @generated
	 */
	String getIsLeaf();

	/**
	 * Sets the value of the '{@link atividade.Function#getIsLeaf <em>Is Leaf</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Leaf</em>' attribute.
	 * @see #getIsLeaf()
	 * @generated
	 */
	void setIsLeaf(String value);

	/**
	 * Returns the value of the '<em><b>Is Abstract</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Abstract</em>' attribute.
	 * @see #setIsAbstract(boolean)
	 * @see atividade.AtividadePackage#getFunction_IsAbstract()
	 * @model
	 * @generated
	 */
	boolean isIsAbstract();

	/**
	 * Sets the value of the '{@link atividade.Function#isIsAbstract <em>Is Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Abstract</em>' attribute.
	 * @see #isIsAbstract()
	 * @generated
	 */
	void setIsAbstract(boolean value);

	/**
	 * Returns the value of the '<em><b>Parameter</b></em>' containment reference list.
	 * The list contents are of type {@link atividade.Parameter}.
	 * It is bidirectional and its opposite is '{@link atividade.Parameter#getFunction <em>Function</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameter</em>' containment reference list.
	 * @see atividade.AtividadePackage#getFunction_Parameter()
	 * @see atividade.Parameter#getFunction
	 * @model opposite="function" containment="true"
	 * @generated
	 */
	EList<Parameter> getParameter();

	/**
	 * Returns the value of the '<em><b>Group</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link atividade.Group#getFunction <em>Function</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Group</em>' container reference.
	 * @see #setGroup(Group)
	 * @see atividade.AtividadePackage#getFunction_Group()
	 * @see atividade.Group#getFunction
	 * @model opposite="function" transient="false"
	 * @generated
	 */
	Group getGroup();

	/**
	 * Sets the value of the '{@link atividade.Function#getGroup <em>Group</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Group</em>' container reference.
	 * @see #getGroup()
	 * @generated
	 */
	void setGroup(Group value);

} // Function
