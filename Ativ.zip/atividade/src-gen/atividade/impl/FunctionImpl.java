/**
 */
package atividade.impl;

import atividade.AtividadePackage;
import atividade.Function;
import atividade.Group;
import atividade.Parameter;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Function</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link atividade.impl.FunctionImpl#getFunctionStatement <em>Function Statement</em>}</li>
 *   <li>{@link atividade.impl.FunctionImpl#getIsLeaf <em>Is Leaf</em>}</li>
 *   <li>{@link atividade.impl.FunctionImpl#isIsAbstract <em>Is Abstract</em>}</li>
 *   <li>{@link atividade.impl.FunctionImpl#getParameter <em>Parameter</em>}</li>
 *   <li>{@link atividade.impl.FunctionImpl#getGroup <em>Group</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FunctionImpl extends ELementImpl implements Function {
	/**
	 * The default value of the '{@link #getFunctionStatement() <em>Function Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionStatement()
	 * @generated
	 * @ordered
	 */
	protected static final String FUNCTION_STATEMENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFunctionStatement() <em>Function Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFunctionStatement()
	 * @generated
	 * @ordered
	 */
	protected String functionStatement = FUNCTION_STATEMENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getIsLeaf() <em>Is Leaf</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsLeaf()
	 * @generated
	 * @ordered
	 */
	protected static final String IS_LEAF_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIsLeaf() <em>Is Leaf</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIsLeaf()
	 * @generated
	 * @ordered
	 */
	protected String isLeaf = IS_LEAF_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsAbstract() <em>Is Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsAbstract()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_ABSTRACT_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsAbstract() <em>Is Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsAbstract()
	 * @generated
	 * @ordered
	 */
	protected boolean isAbstract = IS_ABSTRACT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getParameter() <em>Parameter</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameter()
	 * @generated
	 * @ordered
	 */
	protected EList<Parameter> parameter;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FunctionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AtividadePackage.Literals.FUNCTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFunctionStatement() {
		return functionStatement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFunctionStatement(String newFunctionStatement) {
		String oldFunctionStatement = functionStatement;
		functionStatement = newFunctionStatement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AtividadePackage.FUNCTION__FUNCTION_STATEMENT,
					oldFunctionStatement, functionStatement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIsLeaf() {
		return isLeaf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsLeaf(String newIsLeaf) {
		String oldIsLeaf = isLeaf;
		isLeaf = newIsLeaf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AtividadePackage.FUNCTION__IS_LEAF, oldIsLeaf,
					isLeaf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsAbstract() {
		return isAbstract;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsAbstract(boolean newIsAbstract) {
		boolean oldIsAbstract = isAbstract;
		isAbstract = newIsAbstract;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AtividadePackage.FUNCTION__IS_ABSTRACT, oldIsAbstract,
					isAbstract));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Parameter> getParameter() {
		if (parameter == null) {
			parameter = new EObjectContainmentWithInverseEList<Parameter>(Parameter.class, this,
					AtividadePackage.FUNCTION__PARAMETER, AtividadePackage.PARAMETER__FUNCTION);
		}
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Group getGroup() {
		if (eContainerFeatureID() != AtividadePackage.FUNCTION__GROUP)
			return null;
		return (Group) eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGroup(Group newGroup, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newGroup, AtividadePackage.FUNCTION__GROUP, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setGroup(Group newGroup) {
		if (newGroup != eInternalContainer()
				|| (eContainerFeatureID() != AtividadePackage.FUNCTION__GROUP && newGroup != null)) {
			if (EcoreUtil.isAncestor(this, newGroup))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newGroup != null)
				msgs = ((InternalEObject) newGroup).eInverseAdd(this, AtividadePackage.GROUP__FUNCTION, Group.class,
						msgs);
			msgs = basicSetGroup(newGroup, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AtividadePackage.FUNCTION__GROUP, newGroup,
					newGroup));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__PARAMETER:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getParameter()).basicAdd(otherEnd, msgs);
		case AtividadePackage.FUNCTION__GROUP:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetGroup((Group) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__PARAMETER:
			return ((InternalEList<?>) getParameter()).basicRemove(otherEnd, msgs);
		case AtividadePackage.FUNCTION__GROUP:
			return basicSetGroup(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
		case AtividadePackage.FUNCTION__GROUP:
			return eInternalContainer().eInverseRemove(this, AtividadePackage.GROUP__FUNCTION, Group.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__FUNCTION_STATEMENT:
			return getFunctionStatement();
		case AtividadePackage.FUNCTION__IS_LEAF:
			return getIsLeaf();
		case AtividadePackage.FUNCTION__IS_ABSTRACT:
			return isIsAbstract();
		case AtividadePackage.FUNCTION__PARAMETER:
			return getParameter();
		case AtividadePackage.FUNCTION__GROUP:
			return getGroup();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__FUNCTION_STATEMENT:
			setFunctionStatement((String) newValue);
			return;
		case AtividadePackage.FUNCTION__IS_LEAF:
			setIsLeaf((String) newValue);
			return;
		case AtividadePackage.FUNCTION__IS_ABSTRACT:
			setIsAbstract((Boolean) newValue);
			return;
		case AtividadePackage.FUNCTION__PARAMETER:
			getParameter().clear();
			getParameter().addAll((Collection<? extends Parameter>) newValue);
			return;
		case AtividadePackage.FUNCTION__GROUP:
			setGroup((Group) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__FUNCTION_STATEMENT:
			setFunctionStatement(FUNCTION_STATEMENT_EDEFAULT);
			return;
		case AtividadePackage.FUNCTION__IS_LEAF:
			setIsLeaf(IS_LEAF_EDEFAULT);
			return;
		case AtividadePackage.FUNCTION__IS_ABSTRACT:
			setIsAbstract(IS_ABSTRACT_EDEFAULT);
			return;
		case AtividadePackage.FUNCTION__PARAMETER:
			getParameter().clear();
			return;
		case AtividadePackage.FUNCTION__GROUP:
			setGroup((Group) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case AtividadePackage.FUNCTION__FUNCTION_STATEMENT:
			return FUNCTION_STATEMENT_EDEFAULT == null ? functionStatement != null
					: !FUNCTION_STATEMENT_EDEFAULT.equals(functionStatement);
		case AtividadePackage.FUNCTION__IS_LEAF:
			return IS_LEAF_EDEFAULT == null ? isLeaf != null : !IS_LEAF_EDEFAULT.equals(isLeaf);
		case AtividadePackage.FUNCTION__IS_ABSTRACT:
			return isAbstract != IS_ABSTRACT_EDEFAULT;
		case AtividadePackage.FUNCTION__PARAMETER:
			return parameter != null && !parameter.isEmpty();
		case AtividadePackage.FUNCTION__GROUP:
			return getGroup() != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (functionStatement: ");
		result.append(functionStatement);
		result.append(", isLeaf: ");
		result.append(isLeaf);
		result.append(", isAbstract: ");
		result.append(isAbstract);
		result.append(')');
		return result.toString();
	}

} //FunctionImpl
