/**
 */
package atividade;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link atividade.Group#getVisibility <em>Visibility</em>}</li>
 *   <li>{@link atividade.Group#isIsAbstract <em>Is Abstract</em>}</li>
 *   <li>{@link atividade.Group#getItem <em>Item</em>}</li>
 *   <li>{@link atividade.Group#getFunction <em>Function</em>}</li>
 * </ul>
 *
 * @see atividade.AtividadePackage#getGroup()
 * @model
 * @generated
 */
public interface Group extends ELement {
	/**
	 * Returns the value of the '<em><b>Visibility</b></em>' attribute.
	 * The literals are from the enumeration {@link atividade.Vis}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Visibility</em>' attribute.
	 * @see atividade.Vis
	 * @see #setVisibility(Vis)
	 * @see atividade.AtividadePackage#getGroup_Visibility()
	 * @model
	 * @generated
	 */
	Vis getVisibility();

	/**
	 * Sets the value of the '{@link atividade.Group#getVisibility <em>Visibility</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Visibility</em>' attribute.
	 * @see atividade.Vis
	 * @see #getVisibility()
	 * @generated
	 */
	void setVisibility(Vis value);

	/**
	 * Returns the value of the '<em><b>Is Abstract</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Abstract</em>' attribute.
	 * @see #setIsAbstract(boolean)
	 * @see atividade.AtividadePackage#getGroup_IsAbstract()
	 * @model
	 * @generated
	 */
	boolean isIsAbstract();

	/**
	 * Sets the value of the '{@link atividade.Group#isIsAbstract <em>Is Abstract</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Abstract</em>' attribute.
	 * @see #isIsAbstract()
	 * @generated
	 */
	void setIsAbstract(boolean value);

	/**
	 * Returns the value of the '<em><b>Item</b></em>' containment reference list.
	 * The list contents are of type {@link atividade.Item}.
	 * It is bidirectional and its opposite is '{@link atividade.Item#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Item</em>' containment reference list.
	 * @see atividade.AtividadePackage#getGroup_Item()
	 * @see atividade.Item#getGroup
	 * @model opposite="group" containment="true"
	 * @generated
	 */
	EList<Item> getItem();

	/**
	 * Returns the value of the '<em><b>Function</b></em>' containment reference list.
	 * The list contents are of type {@link atividade.Function}.
	 * It is bidirectional and its opposite is '{@link atividade.Function#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Function</em>' containment reference list.
	 * @see atividade.AtividadePackage#getGroup_Function()
	 * @see atividade.Function#getGroup
	 * @model opposite="group" containment="true"
	 * @generated
	 */
	EList<Function> getFunction();

} // Group
