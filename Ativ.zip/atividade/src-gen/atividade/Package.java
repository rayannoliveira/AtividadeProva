/**
 */
package atividade;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Package</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link atividade.Package#getElement <em>Element</em>}</li>
 * </ul>
 *
 * @see atividade.AtividadePackage#getPackage()
 * @model
 * @generated
 */
public interface Package extends ELement {
	/**
	 * Returns the value of the '<em><b>Element</b></em>' containment reference list.
	 * The list contents are of type {@link atividade.ELement}.
	 * It is bidirectional and its opposite is '{@link atividade.ELement#getPackage <em>Package</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Element</em>' containment reference list.
	 * @see atividade.AtividadePackage#getPackage_Element()
	 * @see atividade.ELement#getPackage
	 * @model opposite="package" containment="true"
	 * @generated
	 */
	EList<ELement> getElement();

} // Package
